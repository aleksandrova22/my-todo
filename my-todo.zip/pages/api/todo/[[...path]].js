import { sql} from "@vercel/postgres";

 const likes = 100;
const { rows } = await sql`SELECT * FROM list`;

// import { neon } from '@neondatabase/serverless';
// const sql = neon(process.env.POSTGRES_URL);

export default async function todo(request, response) {
  const { path } = request.query,
    id = path?.[0];

  console.log('****', { id });
  //const rows = await sql`SELECT * FROM list`;
  response.status(200).json(
    rows
    // [{ "id": 1, "checked": "true", "text": "дело № 1" },
    // { "id": 2, "checked": "true", "text": "дело № 2" }
    // ]  
  
  );
}
